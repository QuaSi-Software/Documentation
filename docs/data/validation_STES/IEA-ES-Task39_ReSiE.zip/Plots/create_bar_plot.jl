###############################################################################
# Absolute bars + % overlay vs ReSiE baseline
#
# - Input: EnergyInput, EnergyOutput, LossTop, LossSide, LossBottom (Float)
# - Any number of scenarios
# - Bars show absolute values
# - Text overlay shows % difference vs baseline (ReSiE)
#   * For losses: % diff computed from TOTAL losses = Top + Side + Bottom
# - Figure has 3 subplots:
#   (1) Energy input (absolute) + % overlay
#   (2) Energy output (absolute) + % overlay
#   (3) Losses stacked (absolute) + % overlay for total losses
###############################################################################

# using CSV
using DataFrames
using Plots

# -------------------------- USER SETTINGS ------------------------------------
baseline_name = "ReSiE"
file_formats  = ["png", "svg"]
showplots     = false

# -------------------------- INPUT TEMPLATE -----------------------------------
# Option A) Define results directly:
main_title = "IEA ES Task 39 testcase TTES-1-AG"
output_name   = "IEA_ES_Task39_TTES-1-AG_energy_balance"
results = DataFrame(
    Scenario    = ["ReSiE", "TRNSYS", "Comsol", "Dymola"],
    EnergyInput = [2816.2, 2812.6, 2906.5, 2917.5],
    EnergyOutput= [2345.3, 2345.5, 2449.0, 2437.7],
    LossTop     = [73.6, 73.3, 74.1, 60.1],
    LossSide    = [368.0, 364.5, 354.4, 382.7],
    LossBottom  = [25.3, 25.4, 21.4, 40.3],
)

# main_title = "IEA ES Task 39 testcase PTES-1-C"
# output_name   = "IEA_ES_Task39_PTES-1-C_energy_balance"
# results = DataFrame(
#     Scenario    = ["ReSiE", "TRNSYS", "Matlab", "Dymola", "Modelica"],
#     EnergyInput = [5620.8, 5600.2, 5626.7, 5777.5, 5567.3],
#     EnergyOutput= [4324.7, 4289.6, 4222.4, 4457.2, 4262.4],
#     LossTop     = [597.6, 588.8, 582.5, 600.1, 586.2],
#     LossSide    = [604.9, 627.1, 631.6, 633.8, 630.2],
#     LossBottom  = [62.6, 61.8, 46.7, 53.5, 55.2],
# )

# main_title = "IEA ES Task 39 testcase PTES-1-P"
# output_name   = "IEA_ES_Task39_PTES-1-P_energy_balance"
# results = DataFrame(
#     Scenario    = ["ReSiE", "TRNSYS", "Comsol"],
#     EnergyInput = [5620.8, 5592.9, 5789.3],
#     EnergyOutput= [4266.8, 4183.0, 4420.7],
#     LossTop     = [634.7, 623.8, 636.9],
#     LossSide    = [631.2, 698.5, 650.5],
#     LossBottom  = [54.2, 51.8, 45.6],
# )

# main_title = "IEA ES Task 39 testcase TTES-1-UG"
# output_name   = "IEA_ES_Task39_TTES-1-UG_energy_balance"
# results = DataFrame(
#     Scenario    = ["ReSiE", "TRNSYS", "Matlab", "Dymola", "Modelica"],
#     EnergyInput = [5746.5, 5716.5, 5735.6, 5885.4, 5815.5],
#     EnergyOutput= [4963.2, 4919.7, 4915.8, 5086.4, 5030.3],
#     LossTop     = [214.6, 209.1, 207.7, 218.5, 217.7],
#     LossSide    = [440.6, 506.7, 492.5, 455.4, 443.5],
#     LossBottom  = [101.5, 51.8, 95.5, 93.1, 96.4],
# )

# Option B) Read from CSV:
# CSV columns must be exactly:
# Scenario,EnergyInput,EnergyOutput,LossTop,LossSide,LossBottom
#
# results = CSV.read("path/to/energy_balance_results.csv", DataFrame; delim=';')  # or delim=','

# -------------------------- STYLE (Tol-like + big fonts) ----------------------
const SCENARIO_PALETTE = [
    "#BB5566", # baseline (ReSiE)
    "#004488", "#DDAA33", "#117733", "#332288", "#AA4499",
    "#44AA99", "#999933", "#882255", "#CC6677", "#DDCC77", "#88CCEE",
]

# Loss component colors (consistent across all cases)
const LOSS_COLORS = ["#004488", "#DDAA33", "#117733"]  # Top, Side, Bottom

const PLOT_KW = (
    grid=true,
    minorgrid=true,
    gridlinewidth=1,
    size=(2400, 900),
    titlefontsize=30,
    guidefontsize=24,
    tickfontsize=24,
    legendfontsize=18,
    margin=5Plots.mm,
)

# -------------------------- HELPERS ------------------------------------------
percent_diff(x::Real, x0::Real) = x0 == 0 ? error("Baseline value is 0. Cannot compute percent difference.") :
                                 100.0 * (x - x0) / x0

fmt_pct(p::Real; digits::Int=1) = (p ≥ 0 ? "+" : "") * string(round(p; digits=digits)) * "%"

function scenario_colors(names::Vector{String}; baseline::String="ReSiE")
    cols = Vector{String}(undef, length(names))
    nonbase_i = 1
    for i in eachindex(names)
        if names[i] == baseline
            cols[i] = SCENARIO_PALETTE[1]
        else
            # cycle through palette entries 2..end
            idx = 1 + ((nonbase_i - 1) % (length(SCENARIO_PALETTE) - 1)) + 1
            cols[i] = SCENARIO_PALETTE[idx]
            nonbase_i += 1
        end
    end
    return cols
end

function ylims_abs(values::AbstractVector{<:Real}; pad::Real=1.15)
    ymax = maximum(values)
    ymin = minimum(values)
    lo = min(0.0, ymin)
    hi = (ymax == 0) ? 1.0 : pad*ymax
    return (lo, hi)
end

function add_pct_annotations!(p, xvals, yvals::Vector{<:Real}, pcts::Vector{<:Real}; ypad_frac::Real=0.03)
    ymax = maximum(yvals)
    yoff = (ymax == 0) ? 1.0 : ypad_frac * ymax
    for i in eachindex(yvals)
        annotate!(p, xvals[i], yvals[i] + yoff, text(fmt_pct(pcts[i]), 18, :black, :center, :bottom))
    end
    return p
end


# -------------------------- MAIN PLOTTING ------------------------------------
function plot_energy_balance_abs_with_pct(results::DataFrame;
        baseline::String="ReSiE",
        output_name::String="energy_balance_abs_with_pct",
        file_formats::Vector{String}=["png"],
        main_title::String="",
        showplots::Bool=false
    )

    required = [:Scenario, :EnergyInput, :EnergyOutput, :LossTop, :LossSide, :LossBottom]
    missing_cols = setdiff(required, Symbol.(names(results)))
    isempty(missing_cols) || error("Missing required columns: $(missing_cols)")

    results = copy(results)
    results.Scenario = String.(results.Scenario)

    base_idx = findfirst(==(baseline), results.Scenario)
    base_idx === nothing && error("Baseline scenario \"$baseline\" not found in results.Scenario.")
    base = results[base_idx, :]

    scen = results.Scenario
    cols = scenario_colors(scen; baseline=baseline)

    # Absolute values
    Ein  = collect(results.EnergyInput)
    Eout = collect(results.EnergyOutput)

    Ltop = collect(results.LossTop)
    Lside = collect(results.LossSide)
    Lbot = collect(results.LossBottom)
    Ltot = Ltop .+ Lside .+ Lbot

    # % differences vs baseline (losses based on TOTAL losses)
    pct_in   = [percent_diff(x, base.EnergyInput) for x in Ein]
    pct_out  = [percent_diff(x, base.EnergyOutput) for x in Eout]
    base_Ltot = base.LossTop + base.LossSide + base.LossBottom
    pct_loss = [percent_diff(x, base_Ltot) for x in Ltot]

    # --- Subplot 1: Energy input (absolute) + % overlay
    p1 = bar(
        scen, Ein;
        color=cols,
        label="",
        title="\nEnergy input",
        xlabel="",
        ylabel="Energy input [MWh]",
        ylims=ylims_abs(Ein),
        xrotation=45,
        legend=false,
        PLOT_KW...
    )
    add_pct_annotations!(p1, scen, Ein, pct_in)

    # --- Subplot 2: Energy output (absolute) + % overlay
    p2 = bar(
        scen, Eout;
        color=cols,
        label="",
        title="\nEnergy output",
        xlabel="",
        ylabel="Energy output [MWh]",
        ylims=ylims_abs(Eout),
        xrotation=45,
        legend=false,
        PLOT_KW...
    )
    add_pct_annotations!(p2, scen, Eout, pct_out)

    # --- Subplot 3: Losses stacked (absolute) using fillto (GR-compatible)

    Ltop  = collect(results.LossTop)
    Lside = collect(results.LossSide)
    Lbot  = collect(results.LossBottom)

    L12   = Lbot .+ Lside
    Ltot  = L12  .+ Ltop

    p3 = bar(
        scen, Lbot;
        fillto=0,                 # baseline of first stack
        color=LOSS_COLORS[1],
        label="Loss bottom",
        title="\nLosses",
        xlabel="",
        ylabel="Losses [MWh]",
        ylims=ylims_abs(Ltot),
        xrotation=45,
        PLOT_KW...,
        legend = (0.65, 0.35),
    )

    bar!(p3,
        scen, L12;
        fillto=Lbot,              # stack on top of LossTop
        color=LOSS_COLORS[2],
        label="Loss side",
    )

    bar!(p3,
        scen, Ltot;
        fillto=L12,               # stack on top of (LossBottom+LossSide)
        color=LOSS_COLORS[3],
        label="Loss top",
    )

    # % overlay computed on TOTAL losses
    base_Ltot = base.LossTop + base.LossSide + base.LossBottom
    pct_loss  = [percent_diff(x, base_Ltot) for x in Ltot]
    add_pct_annotations!(p3, scen, Ltot, pct_loss)

    # Combine into one figure
    p = plot(
        p1, p2, p3; 
        layout=(1, 3), 
        size=(2400, 900), 
        plot_title = main_title,
        plot_titlefontsize = 34,
        plot_titlelocation = :center,
        margin=25Plots.mm
        )

    # Save
    for fmt in file_formats
        savefig(p, output_name * "." * fmt)
    end

    if showplots
        gui()
        println("Press Enter to close program and all figures...")
        readline()
    end

    return p
end

# -------------------------- RUN ------------------------------------------------
plot_energy_balance_abs_with_pct(
    results;
    baseline=baseline_name,
    output_name=output_name,
    file_formats=file_formats,
    main_title=main_title,
    showplots=showplots
)
