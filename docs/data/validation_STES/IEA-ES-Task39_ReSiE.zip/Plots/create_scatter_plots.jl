using DataFrames
using XLSX
using Plots
using Statistics
using Printf

# -------------------------- SETTINGS -----------------------------------------
excel_path = "C:/Users/steinacker/Lokal/git_ReSiE_new/resie/helper_functions/create_IEA_ES_Task39_plots/Compare_Temp_E.xlsx"
baseline_name = "ReSiE"

out_dir = "C:/Users/steinacker/Lokal/git_ReSiE_new/resie/helper_functions/create_IEA_ES_Task39_plots/"          # change if you want
save_formats = ["png", "svg"]

# Style (keep similar to your previous script)
const SCENARIO_PALETTE = ["#BB5566",
                          "#004488", "#DDAA33", "#117733", "#332288", "#AA4499",
                          "#44AA99", "#999933", "#882255", "#CC6677", "#DDCC77", "#88CCEE"]

const PLOT_KW = (grid=true,
                 minorgrid=true,
                 gridlinewidth=1,
                 titlefontsize=22,
                 guidefontsize=18,
                 tickfontsize=16,
                 legendfontsize=14,
                 margin=10Plots.mm)

# -------------------------- HELPERS ------------------------------------------

rmse(x::AbstractVector{<:Real}, y::AbstractVector{<:Real}) = sqrt(mean((y .- x) .^ 2))
mbe(x::AbstractVector{<:Real}, y::AbstractVector{<:Real}) = mean(y .- x)

fmt_signed(v; digits=3) = (v ≥ 0 ? "+" : "") * string(round(v; digits=digits))

# Percent KPIs using baseline mean (common/simple):
# NMBE[%]   = 100 * mean(y-x) / mean(x)
# CVRMSE[%] = 100 * RMSE / mean(x)
function nmbe_percent(x::AbstractVector{<:Real}, y::AbstractVector{<:Real})
    mx = mean(x)
    mx == 0 && return NaN
    return 100 * mbe(x, y) / mx
end

function cvrmse_percent(x::AbstractVector{<:Real}, y::AbstractVector{<:Real})
    mx = mean(x)
    mx == 0 && return NaN
    return 100 * rmse(x, y) / mx
end

# Place a 2-line metric overlay in the top-left of the subplot (data coords, robust)
function add_metrics_overlay!(p, x::Vector{Float64}, y::Vector{Float64};
                              mode::Symbol, unit::String="", digits::Int=3)
    xlims = Plots.xlims(p)
    ylims = Plots.ylims(p)
    x0 = xlims[1] + 0.03 * (xlims[2] - xlims[1])
    y0 = ylims[2] - 0.05 * (ylims[2] - ylims[1])

    if mode == :abs
        r = rmse(x, y)
        b = mbe(x, y)
        txt = "RMSE = $(round(r; digits=digits)) $(unit)\nMBE  = $(fmt_signed(b; digits=digits)) $(unit)"
        annotate!(p, x0, y0, text(txt, 14, :black, :left, :top))
    elseif mode == :pct
        cv = cvrmse_percent(x, y)
        nb = nmbe_percent(x, y)
        txt = "CVRMSE = $(round(cv; digits=digits)) %\nNMBE   = $(fmt_signed(nb; digits=digits)) %"
        annotate!(p, x0, y0, text(txt, 14, :black, :left, :top))
    else
        error("Unknown mode=$(mode). Use :abs or :pct.")
    end

    return p
end

function finite_pair(x, y)
    @assert length(x) == length(y)
    m = isfinite.(x) .& isfinite.(y)
    return x[m], y[m]
end

function lims_equal(x, y; pad_frac=0.03)
    lo = min(minimum(x), minimum(y))
    hi = max(maximum(x), maximum(y))
    span = hi - lo
    pad = span == 0 ? 1.0 : pad_frac * span
    return (lo - pad, hi + pad)
end

# choose a nice layout for 2..4 comparisons (works beyond too)
best_layout(n) = n <= 3 ? (1, n) : (2, cld(n, 2))

# Parse columns like "Model_Tout" and "Model_E" from a sheet
function extract_models(df::DataFrame; baseline="ReSiE")
    cn = String.(names(df))

    # map: model => Dict(:Tout => colname, :E => colname)
    modelcols = Dict{String,Dict{Symbol,String}}()

    for c in cn
        # ignore time/index columns if present
        lc = lowercase(c)
        if lc in ("time", "t", "index", "step", "timestamp")
            continue
        end

        # expect "Model_Tout" or "Model_E"
        if occursin("_", c)
            parts = split(c, "_")
            var = parts[end]
            model = join(parts[1:(end - 1)], "_")

            if var == "Tout" || var == "TOUT" || var == "tout"
                get!(modelcols, model, Dict{Symbol,String}())[:Tout] = c
            elseif var == "E" || var == "e"
                get!(modelcols, model, Dict{Symbol,String}())[:E] = c
            end
        end
    end

    # baseline must have both
    haskey(modelcols, baseline) ||
        error("Baseline model '$baseline' not found (need columns like $(baseline)_Tout and $(baseline)_E).")
    for v in (:Tout, :E)
        haskey(modelcols[baseline], v) || error("Missing baseline column for $v (need $(baseline)_$v).")
    end

    # keep only models that have both variables
    models = String[]
    for (m, d) in modelcols
        (haskey(d, :Tout) && haskey(d, :E)) && push!(models, m)
    end
    sort!(models)

    # comparisons exclude baseline
    comps = filter(!=(baseline), models)

    return modelcols, comps
end

function to_float_vec(col)
    # Convert common Excel types to Float64; missings become NaN for isfinite filtering
    v = collect(col)
    out = Vector{Float64}(undef, length(v))
    for i in eachindex(v)
        if v[i] === missing || v[i] === nothing
            out[i] = NaN
        else
            out[i] = Float64(v[i])
        end
    end
    return out
end

function scatter_subplot(xbase, ycomp; lims, title, xlabel, ylabel, color,
                         kpi_mode::Symbol, unit::String="")
    x, y = finite_pair(xbase, ycomp)

    p = scatter(x, y;
                markersize=2.2,
                markerstrokewidth=0,
                color=color,
                label="",
                title=title,
                xlabel=xlabel,
                ylabel=ylabel,
                xlims=lims,
                ylims=lims,
                aspect_ratio=:equal,
                legend=false,
                PLOT_KW...)

    # y=x reference line (thin)
    xs = [lims[1], lims[2]]
    plot!(p, xs, xs; linewidth=1, color=:black, alpha=0.6, label="")

    # KPI overlay
    add_metrics_overlay!(p, x, y; mode=kpi_mode, unit=unit, digits=3)

    return p
end

function plot_testcase_sheet(excel_path::String, sheet::String; baseline="ReSiE")
    df = DataFrame(XLSX.readtable(excel_path, sheet; infer_eltypes=true))

    modelcols, comps = extract_models(df; baseline=baseline)
    n = length(comps)
    n == 0 && error("Sheet '$sheet': no comparison models found with both Tout and E columns.")

    print_kpis_to_console(sheet, baseline, df, modelcols, comps)

    # baseline vectors
    xTout = to_float_vec(df[!, modelcols[baseline][:Tout]])
    xE = to_float_vec(df[!, modelcols[baseline][:E]])

    # compute global limits per variable (per testcase) for consistent visuals
    # (use baseline + all comparisons)
    allTout = [xTout]
    allE = [xE]
    for m in comps
        push!(allTout, to_float_vec(df[!, modelcols[m][:Tout]]))
        push!(allE, to_float_vec(df[!, modelcols[m][:E]]))
    end

    # global lims: flatten finite values
    function global_lims(vs)
        vv = reduce(vcat, vs)
        vv = vv[isfinite.(vv)]
        span = maximum(vv) - minimum(vv)
        pad = span == 0 ? 1.0 : 0.03 * span
        return (minimum(vv) - pad, maximum(vv) + pad)
    end

    limsTout = global_lims(allTout)
    limsE = global_lims(allE)

    # colors per comparison
    cols = [SCENARIO_PALETTE[1 + ((i - 1) % (length(SCENARIO_PALETTE) - 1)) + 1] for i in 1:n]

    # ---- Figure 1: Tout
    psTout = Plots.Plot[]
    for (i, m) in enumerate(comps)
        yTout = to_float_vec(df[!, modelcols[m][:Tout]])
        push!(psTout,
              scatter_subplot(xTout, yTout;
                              lims=limsTout,
                              title="$(m) vs $(baseline)",
                              xlabel="$(baseline) Tout [°C]",
                              ylabel="$(m) Tout [°C]",
                              color=cols[i],
                              kpi_mode=:abs,
                              unit="°C",))
    end

    lay = best_layout(n)
    sizeTout = (650 * lay[2], 520 * lay[1] + 150)
    pTout = plot(psTout...;
                 layout=lay,
                 size=sizeTout,
                 plot_title="$(sheet) — STES output temperature",
                 plot_titlefontsize=26,
                 plot_titlevspan=0.08,
                 top_margin=14Plots.mm,)

    # ---- Figure 2: E (energy content)
    psE = Plots.Plot[]
    for (i, m) in enumerate(comps)
        yE = to_float_vec(df[!, modelcols[m][:E]])
        push!(psE,
              scatter_subplot(xE, yE;
                              lims=limsE,
                              title="$(m) vs $(baseline)",
                              xlabel="$(baseline) Energy [MWh]",
                              ylabel="$(m) Energy [MWh]",
                              color=cols[i],
                              kpi_mode=:pct,
                              unit="",))
    end

    sizeE = (650 * lay[2], 520 * lay[1] + 150)
    pE = plot(psE...;
              layout=lay,
              size=sizeE,
              plot_title="$(sheet) — STES energy content",
              plot_titlefontsize=26,
              plot_titlevspan=0.08,
              top_margin=14Plots.mm,)

    # Save
    safe = replace(sheet, r"[^\w\-]+" => "_")
    for fmt in save_formats
        savefig(pTout, joinpath(out_dir, "260205_IEA_ES_Task39_$(safe)_Tout.$(fmt)"))
        savefig(pE, joinpath(out_dir, "260205_IEA_ES_Task39_$(safe)_Energy.$(fmt)"))
    end

    return pTout, pE
end

function print_kpis_to_console(sheet::String, baseline::String,
                               df::DataFrame, modelcols, comps)

    # baseline vectors
    xTout = to_float_vec(df[!, modelcols[baseline][:Tout]])
    xE    = to_float_vec(df[!, modelcols[baseline][:E]])

    println("\n================ KPI SUMMARY =================")
    println("Testcase sheet: $sheet")
    println("Baseline: $baseline")
    println("Metrics computed on finite paired samples (finite_pair).")
    println("--------------------------------------------------------------")

    # Header
    @printf("%-18s | %10s %10s %6s | %10s %10s %6s\n",
            "Model",
            "RMSE_T", "MBE_T", "nT",
            "CVRMSE_E%", "NMBE_E%", "nE")
    println("-"^78)

    for m in comps
        # comparison vectors
        yTout = to_float_vec(df[!, modelcols[m][:Tout]])
        yE    = to_float_vec(df[!, modelcols[m][:E]])

        # Tout KPIs (absolute)
        xT, yT = finite_pair(xTout, yTout)
        rT = rmse(xT, yT)
        bT = mbe(xT, yT)
        nT = length(xT)

        # Energy KPIs (percent)
        xEn, yEn = finite_pair(xE, yE)
        cvE = cvrmse_percent(xEn, yEn)
        nbE = nmbe_percent(xEn, yEn)
        nE  = length(xEn)

        @printf("%-18s | %10.3f %10.3f %6d | %10.3f %10.3f %6d\n",
                m, rT, bT, nT, cvE, nbE, nE)
    end

    println("==============================================================\n")
    return nothing
end


# -------------------------- RUN ALL TESTCASES --------------------------------
xf = XLSX.readxlsx(excel_path)
sheets = XLSX.sheetnames(xf)   # list all testcase sheets :contentReference[oaicite:2]{index=2}

for sh in sheets
    plot_testcase_sheet(excel_path, sh; baseline=baseline_name)
end
