###############################################################################
# ReSiE mesh convergence – stacked losses bar plot (GR-compatible)
###############################################################################

using DataFrames
using Plots

# -------------------------- DATA (INPUT TEMPLATE) ----------------------------
df = DataFrame(
    resolution   = ["very_rough", "rough", "high", "very_high"],
    LossesBottom = [101368309,    102884641, 105248904, 105476979] ./ 1000_000,
    LossesSide   = [444587721,    446872970, 451784250, 452898653]./ 1000_000,
    LossesTop    = [214117693,    214156969, 214104052, 214062092]./ 1000_000,
)

# -------------------------- STYLE --------------------------------------------
const LOSS_COLORS = ["#117733", "#DDAA33", "#004488"]  # bottom, side, top (Tol-like)

const PLOT_KW = (
    grid=true,
    minorgrid=true,
    gridlinewidth=1,
    size=(1400, 800),
    titlefontsize=28,
    guidefontsize=22,
    tickfontsize=18,
    legendfontsize=18,
    margin=15Plots.mm,
)

# -------------------------- HELPERS ------------------------------------------
# nice compact scientific label for big totals
fmt_sci(x) = string(round(x; sigdigits=4))  # change to @sprintf("%.3e", x) if you prefer

function ylims_abs(v; pad=1.12)
    vmax = maximum(v)
    return (0.0, vmax == 0 ? 1.0 : pad * vmax)
end

# -------------------------- PLOT ---------------------------------------------
res = df.resolution
x = 1:length(res)

Lbot = Float64.(df.LossesBottom)
Lside = Float64.(df.LossesSide)
Ltop = Float64.(df.LossesTop)

L12  = Lbot .+ Lside
Ltot = L12  .+ Ltop

p = bar(
    x, Lbot;
    fillto=0,
    color=LOSS_COLORS[1],
    label="Losses bottom",
    title="Mesh sensitivity of STES model in ReSiE - Losses",
    xlabel="Mesh resolution",
    ylabel="Losses [MWh]",
    xticks=(x, res),
    xrotation=0,
    ylims=ylims_abs(Ltot),
    legend=:right,
    PLOT_KW...
)

bar!(p,
    x, L12;
    fillto=Lbot,
    color=LOSS_COLORS[2],
    label="Losses side",
)

bar!(p,
    x, Ltot;
    fillto=L12,
    color=LOSS_COLORS[3],
    label="Losses top",
)

# Optional: total labels above bars
yoff = 0.02 * maximum(Ltot)
for i in eachindex(x)
    annotate!(p, x[i], Ltot[i] + yoff, text(fmt_sci(Ltot[i]), 16, :black, :center, :bottom))
end

# Save (adjust filenames/formats as needed)
savefig(p, "260205_IEA_ES_Task39_TTES-1-UG_mesh_sensitivity.png")
savefig(p, "260205_IEA_ES_Task39_TTES-1-UG_mesh_sensitivity.svg")

display(p)
